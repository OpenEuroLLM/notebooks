#!/bin/bash
#
# Author: Jenia Jitsev, Mar 2025
#
#
# Usage:
#   ./copy_checkpoint_to_continue.sh <train_log_file> <new_samples_value>
#
# Example:
#   ./copy_checkpoint_to_continue.sh training.log 1T
#
# This script will:
#   1) Find the iteration at which LR first cools down from its plateau.
#   2) Extract from the log the base checkpoint path used when saving that iteration.
#   3) Construct a new checkpoint path, replacing the old 'samples-XYZ' with 'samples-<new_samples_value>',
#      and appending "_continue_samples-XYZ_iter-<iteration>" to the folder name.
#   4) create a symlink subfolder (iter_00xxxx) in the new path to the old path.

set -eu -o pipefail

LOG_GLOB="${1:-}"
NEW_SAMPLES="${2:-}"

if [[ -z "$LOG_GLOB" || -z "$NEW_SAMPLES" ]]; then
  echo "Usage: $0 \"/path/to/log_files_*.out\" <new_samples_value>"
  echo "Example: $0 \"/PATH/LOG_NAME_*.out\" 1T"
  return 1
fi

##############################################################################
# Collect the log files in sorted order
##############################################################################
# We'll store them in an array LOG_FILES, by listing & sorting them.  
# This ensures AWK processes them in the correct sequence.
#
# If your log files are definitely appended in the correct alphabetical order,
# you can rely on a simple sort. Otherwise, you might want `sort -V` or `sort -t`.
##############################################################################

mapfile -t LOG_FILES < <(ls -1 ${LOG_GLOB} 2>/dev/null | sort)
if [[ "${#LOG_FILES[@]}" -eq 0 ]]; then
  echo "[Error] No log files found matching pattern: $LOG_GLOB"
  return 1
fi

echo "Found ${#LOG_FILES[@]} log files:"
printf '  %s\n' "${LOG_FILES[@]}"

##############################################################################
# 1. First pass: find the maximum (plateau) LR in the entire log
##############################################################################
MAX_LR=$(
  awk '
    /learning rate:/ {
      match($0, /learning rate:[[:space:]]+([0-9.Ee+\-]+)/, m)
      lr_val = m[1] + 0
      if (lr_val > max_lr) {
        max_lr = lr_val
      }
    }
    END {
      print max_lr
    }
  ' "${LOG_FILES[@]}"
)

re='^[0-9]+([.][0-9]+)?$'

if ! [[ $MAX_LR =~ $re ]]
then
  echo "MAX_LR not found, no const lr phase detected"
  return 1
else
  echo "MAX_LR found: ${MAX_LR}"
fi

##############################################################################
# 2. Second pass: find the iteration where LR first drops below that plateau
#    BUT only after we have actually seen that plateau at least once
##############################################################################
ITERATION_COOLDOWN=$(awk -v max_lr="$MAX_LR" '
  BEGIN {
    plateau_seen = 0
    current_ckpt = ""
  }

  # Catch lines like:
  # [lrdn0021:0]:  successfully saved checkpoint from iteration   58000 to ...
  /successfully saved checkpoint from iteration[[:space:]]+([0-9]+)/ {
    match($0, /successfully saved checkpoint from iteration[[:space:]]+([0-9]+)/, ckpt)
    current_ckpt = ckpt[1]
  }

  # Catch lines that contain the learning rate
  /learning rate:/ {
    # Extract iteration
    match($0, /iteration[[:space:]]+([0-9]+)/, iter)
    # Extract LR
    match($0, /learning rate:[[:space:]]+([0-9.Ee+\-]+)/, lr)
    this_lr = lr[1] + 0.0

    # With possible tiny floating differences, define a small tolerance:
    tol = 1e-12

    # If we havent yet recognized we are "on plateau," check:
    # (this_lr is close enough to max_lr to treat them as equal)
    if (!plateau_seen &&
        (this_lr >= max_lr - tol) &&
        (this_lr <= max_lr + tol)) {
      plateau_seen = 1
    }

    # Once we are on plateau, watch for a drop below it:
    else if (plateau_seen && this_lr < max_lr - tol) {
      # Print the last checkpoint iteration we saw, then exit
      if (length(current_ckpt) > 0) {
        print current_ckpt
      }
      exit
    }
  }
' "${LOG_FILES[@]}"
)


if [[ "$ITERATION_COOLDOWN" == "-1" ]]; then
  echo "[Error] Could not find any iteration where LR drops below plateau."
  return 1
fi

echo "Detected LR cooldown at iteration: $ITERATION_COOLDOWN"

##############################################################################
# 3. Extract the checkpoint base path for *that* iteration from the log
#
#    We look for lines like:
#       saving checkpoint at iteration   X to /some/path [ANY TEXT...]
#    or
#       successfully saved checkpoint from iteration   X to /some/path [ANY TEXT...]
#
#    We extract ONLY the portion immediately after 'to' up to the next whitespace.
#    (Assuming HPC checkpoint paths do not contain spaces.)
##############################################################################
CKPT_BASE_PATH=$(
  awk -v tgt_iter="$ITERATION_COOLDOWN" '
    /saving checkpoint at iteration/ || /successfully saved checkpoint from iteration/ {
      match($0, /iteration[[:space:]]+([0-9]+)/, arr)
      if (arr[1] == tgt_iter) {
        # Extract the checkpoint path up to the next space (no spaces in HPC paths).
        # " to /some/path extra stuff"
        # We ll match " to[[:space:]]+([^[:space:]]+)"
        if (match($0, / to[[:space:]]+([^[:space:]]+)/, p)) {
          print p[1]
          exit
        }
      }
    }
  ' "${LOG_FILES[@]}"
)

if [[ -z "$CKPT_BASE_PATH" ]]; then
  echo "[Error] Could not find checkpoint path for iteration ${ITERATION_COOLDOWN} in the log."
  return 1
fi

echo "Original checkpoint base path = $CKPT_BASE_PATH"

##############################################################################
# 4. Build the new checkpoint folder name
#
#    - Replace "samples-OLD" with "samples-$NEW_SAMPLES".
#    - Append "_continue_samples-OLD_iter-<ITERATION_COOLDOWN>".
#
#    We'll parse out the last folder name, do the transformations, then join.
##############################################################################

# Grab old folder name (e.g. "open-sci-ref_model-1.7b_data-...-LEONARDO")
OLD_FOLDER="$(basename "$CKPT_BASE_PATH")"
# Grab parent dir
PARENT_DIR="$(dirname "$CKPT_BASE_PATH")"

# Extract old sample token (the stuff after "samples-" up to the next underscore)
# e.g. for "samples-300B", old_samples -> "300B"
OLD_SAMPLES=$(echo "$OLD_FOLDER" | sed -n 's/.*samples-\([^_]*\).*/\1/p')
if [[ -z "$OLD_SAMPLES" ]]; then
  echo "[Warning] Could not parse old sample label from folder name. Will proceed anyway."
  # Fallback to "???"
  OLD_SAMPLES="???"
fi

# Replace the old "samples-300B" with "samples-<NEW_SAMPLES>"
TMP_FOLDER=$(echo "$OLD_FOLDER" | sed "s/samples-$OLD_SAMPLES/samples-$NEW_SAMPLES/")
# Now append the suffix: _continue_samples-300B_iter-58000
NEW_FOLDER="${TMP_FOLDER}_continue_samples-${OLD_SAMPLES}_iter-${ITERATION_COOLDOWN}"

# Combine to form the new path
NEW_CKPT_PATH="${PARENT_DIR}/${NEW_FOLDER}"

echo "Will copy to new checkpoint path = $NEW_CKPT_PATH"

##############################################################################
# 5. Create the subfolder symlink, instead of copying via rsync
##############################################################################
PADDED_ITER=$(printf "%07d" "${ITERATION_COOLDOWN}")
ITER_SUBFOLDER="iter_${PADDED_ITER}"

mkdir -p "$NEW_CKPT_PATH"

SRC_SUBFOLDER="${CKPT_BASE_PATH}/${ITER_SUBFOLDER}"
DST_SUBFOLDER="${NEW_CKPT_PATH}/${ITER_SUBFOLDER}"

# Create symbolic link to the original folder
echo "Creating symlink from:"
echo "   $DST_SUBFOLDER"
echo "-> $SRC_SUBFOLDER"

ln -s "$SRC_SUBFOLDER" "$DST_SUBFOLDER"

echo "Done. New checkpoint folder: ${DST_SUBFOLDER}"

##############################################################################
# 6. Create/overwrite "latest_checkpointed_iteration.txt" at NEW_CKPT_PATH
#
#    We put ITERATION_COOLDOWN in that file, so the new checkpoint
#    can be used to continue training from iteration ITERATION_COOLDOWN.
##############################################################################
echo "$ITERATION_COOLDOWN" > "${NEW_CKPT_PATH}/latest_checkpointed_iteration.txt"
echo "Wrote ${NEW_CKPT_PATH}/latest_checkpointed_iteration.txt with iteration ${ITERATION_COOLDOWN}"